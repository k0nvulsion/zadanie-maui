﻿namespace MauiApp2
{

    public partial class MainPage : ContentPage
    {
        private const string TekstPoczatkowy = "Wprowadź dane i kliknij Oblicz...";

        public MainPage()
        {
            InitializeComponent();
        }

        private bool DaneSaPoprawne()
        {
            return !string.IsNullOrWhiteSpace(entryKlient.Text)
                && !string.IsNullOrWhiteSpace(entryUrzadzenie.Text);
        }

        private void OnObliczClicked(object sender, EventArgs e)
        {
            if (!DaneSaPoprawne())
            {
                lblPodsumowanie.Text = "Błąd: wpisz dane klienta oraz model urządzenia.";
                lblPodsumowanie.TextColor = Colors.Red;
                return;
            }

            decimal kwotaBazowa = rbPlyta.IsChecked
                ? 250m
                : rbSystem.IsChecked
                    ? 150m
                    : 100m;

            decimal suma = kwotaBazowa;

            if (cbKopia.IsChecked)
                suma += 80m;

            if (cbPasta.IsChecked)
                suma += 40m;

            if (swEkspres.IsToggled)
                suma *= 1.5m;

            bool rabatZastosowany =
                string.Equals(
                    entryKod.Text?.Trim().ToUpperInvariant(),
                    "TECHNIK10",
                    StringComparison.Ordinal);

            if (rabatZastosowany)
                suma *= 0.9m;

            string rabatInfo = rabatZastosowany
                ? "Rabat TECHNIK10: -10%"
                : "Rabat: brak";

            lblPodsumowanie.Text =
                $"Klient: {entryKlient.Text.Trim()}\n" +
                $"Urządzenie: {entryUrzadzenie.Text.Trim()}\n" +
                $"Kwota do zapłaty: {suma:0.00} zł\n" +
                rabatInfo;

            lblPodsumowanie.TextColor = Colors.Black;
        }

        private void OnWyczyscClicked(object sender, EventArgs e)
        {
            entryKlient.Text = string.Empty;
            entryUrzadzenie.Text = string.Empty;
            entryKod.Text = string.Empty;

            rbDiagnostyka.IsChecked = true;
            rbSystem.IsChecked = false;
            rbPlyta.IsChecked = false;

            cbKopia.IsChecked = false;
            cbPasta.IsChecked = false;
            swEkspres.IsToggled = false;

            lblPodsumowanie.Text = TekstPoczatkowy;
            lblPodsumowanie.TextColor = Colors.Black;
        }

        private async void OnZatwierdzClicked(object sender, EventArgs e)
        {
            if (!DaneSaPoprawne())
            {
                await DisplayAlertAsync(
                    "Błąd",
                    "Wpisz dane klienta oraz model urządzenia.",
                    "OK");
                return;
            }

            await DisplayAlertAsync(
                "Zlecenie przyjęte",
                $"Przyjęto zlecenie dla: {entryKlient.Text.Trim()}.\n" +
                $"Urządzenie: {entryUrzadzenie.Text.Trim()}.",
                "OK");
        }
    }
}
